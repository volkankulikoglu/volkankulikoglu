package com.works.productclient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

	@GetMapping("/allProduct")
	public Map<String, Object> allProduct() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();

		
		Product product1 = new Product();
		product1.setTitle("Buzdolabı");
		product1.setPrice(2000);
		
		Product product2 = new Product();
		product2.setTitle("Televizyon");
		product2.setPrice(1000);
		
		List<Product> ls = new ArrayList<Product>();
		
		ls.add(product1);
		ls.add(product2);
		
		hm.put("statu", true);
		hm.put("allProduct", ls);
		
		return hm;
	}
}
