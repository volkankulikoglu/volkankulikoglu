package appPack;

import java.io.ObjectInputStream.GetField;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MainApp {

	public static void main(String[] args) {

		DB db = new DB();
		String query = "insert into user values( null, ?, ? , now())";
		// INSERT INTO `user` (`uid`, `name`, `surname`, `udate`) VALUES (NULL, 'Kemal',
		// 'Bilir', '2020-04-06 07:13:16');

		try {
			PreparedStatement pre = db.connect(query);
			pre.setString(1, "Ayşe");
			pre.setString(2, "Test");

			int statu = pre.executeUpdate(); // insert , update , delete
			ResultSet ids = pre.getGeneratedKeys();

			if (ids.next()) {
				int id = ids.getInt(1);
				System.out.println("insert id :" + id);
			}

			if (statu > 0) {
				System.out.println("insert success");
			} else {
				System.out.println("insert fail");
				// db.conn.commit();();
				// db.conn.rollback();
			}

		} catch (Exception e) {
			System.err.println("insert error :" + e);
		}

		dataResult();

	}

	public static void dataResult() {
		DB db = new DB();
		String query = "select * from user limit 0, 1";
		//String query = "select * from where name = ?";

		try {
			PreparedStatement pre = db.connect(query);
			//pre.setString(1, "Ayşe");
			ResultSet rs = pre.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("uid");
				String name = rs.getString("name");
				System.out.println("uid :" + id);
				System.out.println("name :" + name);

			}

			// single
			if (rs.next()) {
				int id = rs.getInt("uid");
				String name = rs.getString("name");
				System.out.println("Single uid :" + id);
				System.out.println("single name :" + name);
			}

		} catch (Exception e) {
			System.err.println("select error :" + e);
		}
	}

}
