package com.works.loglombok;

import lombok.Data;

@Data
//@AllArgsConstructor
public class User {

	private String name;
	private int age;
}
