package appPack;

import java.util.Timer;
import java.util.TimerTask;

public class MainApp {

	public static void main(String[] args) {

		UserResult us = new UserResult(1);
		Thread th1 = new Thread(us);
		th1.start();

		UserResult us1 = new UserResult(2);
		Thread th2 = new Thread(us1);
		th2.start();

		System.out.println("MainApp Call");

		Runnable rn = () -> {

			for (;;) {
				System.out.println("Runnable Call");

				try {
					Thread.sleep(1000);
				} catch (Exception e) {

				}
			}
		};
		new Thread(rn).start();

		Timer tm = new Timer();
		tm.schedule(task, 100, 1000);

	}

	static TimerTask task = new TimerTask() {

		@Override
		public void run() {
			call();
		}
	};

	static public void call() {
		System.out.println("Timer Call");
	}

}
