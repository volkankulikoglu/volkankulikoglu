package appPack;

public class UserResult implements Runnable {

	int a = 0;
	public UserResult(int a) {
		this.a = a;
	}

	@Override
	public void run() {

		for (;;) {
			System.out.println("run Call" + a);

			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}

}
