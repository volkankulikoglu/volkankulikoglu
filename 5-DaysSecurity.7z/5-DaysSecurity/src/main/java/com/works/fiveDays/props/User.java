package com.works.fiveDays.props;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.works.fiveDays.usingValidation.UniValid;



public class User {
	
	@NotBlank(message = "Name boş olamaz")
	@NotEmpty(message = "Name datası giriniz")
	private String name;
	
	@Min(value = 10, message = "en az 10 giriniz")
	@Max(value = 100, message = "en fazla 100 giriniz")
	private int age;
	
	@Email(message = "Hatali email")
	private String mail;
	
	@UniValid(message = "Lütfen geçerli bir üni girin.")
	private String uni;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getUni() {
		return uni;
	}
	public void setUni(String uni) {
		this.uni = uni;
	}

}
