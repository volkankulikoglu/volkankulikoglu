package appPack;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import props.User;
import props.UEnum;

public class MainHashMap {

	public static void main(String[] args) {

		HashMap<String, User> hm = fncResult();

		Map<String, User> hml = fncMapResult();

		User u = hm.get("name1");
		System.out.println("Name : " + u.getName());

		Set<String> keys = hm.keySet();

		for (String key : keys) {
			User us = hm.get(key);

			System.out.println("Name : " + us.getName());
		}

		System.out.println(hm);
		hml.remove("name0");
		System.out.println(hml);

		System.out.println(hml.size());

		Map<UEnum, String> eHash = fnEnumResult();
		System.out.println(eHash.get(UEnum.name));
	}

	public static HashMap<String, User> fncResult() {

		HashMap<String, User> hm = new HashMap<>();

		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setAge(i);
			us.setName("Ali" + i);

			hm.put("name" + i, us);
		}

		return hm;

	}

	public static Map<String, User> fncMapResult() {

		Map<String, User> hm = new LinkedHashMap<>();

		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setAge(i);
			us.setName("Ali" + i);

			hm.put("name" + i, us);
		}

		return hm;

	}

	public static Map<UEnum, String> fnEnumResult() {

		Map<UEnum, String> hm = new LinkedHashMap<>();
		hm.put(UEnum.name, "Ali");
		hm.put(UEnum.surname, "Bilmem");
		hm.put(UEnum.age, "40");

		// System.out.println(UEnum.values()[0]);

		return hm;

	}
}
