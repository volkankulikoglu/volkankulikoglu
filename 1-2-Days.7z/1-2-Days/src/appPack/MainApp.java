package appPack;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import props.User;

public class MainApp {

	public static void main(String[] args) {

		List<User> ls = dataResult();

		long start = System.currentTimeMillis();

		for (User item : ls) {
			System.out.println("Name : " + item.getName());

		}

		long end = System.currentTimeMillis();

		long time = end - start;

		System.out.println("Time : " + time);

		ls.forEach(item -> {
			System.out.println("Name foreach : " + item.getName());

		});
		
		System.out.println(ls.size());
		System.out.println(ls.get(5));
		
		ls.stream().filter(item -> item.getAge() == 5).forEach(item -> {  });
		
		
		//Collections.sort(ls);

	}

	public static List<User> dataResult() {

		List<User> ls = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			User us = new User();
			us.setName("Mehmet" + i);
			us.setAge(i);

			ls.add(us);
		}

		return ls;

	}

}
