package com.works.ClientSoap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.ClientSoap.client.SoapClient;
import com.works.ClientSoap.bindings.GetBookRequest;
import com.works.ClientSoap.bindings.GetBookResponse;

@RestController
public class BookController {

	@Autowired
	SoapClient soapClient;

	@PostMapping("/getBooks")
	public GetBookResponse item(@RequestBody GetBookRequest bookRequest) {

		return soapClient.getItem(bookRequest);
	}
}
