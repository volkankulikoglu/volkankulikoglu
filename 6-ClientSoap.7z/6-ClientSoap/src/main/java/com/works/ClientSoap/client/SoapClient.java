package com.works.ClientSoap.client;

import java.io.IOException;

import javax.xml.namespace.QName;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.works.ClientSoap.bindings.GetBookRequest;
import com.works.ClientSoap.bindings.GetBookResponse;

@Service
public class SoapClient {

	@Autowired
	Jaxb2Marshaller jaxb2Marshaller;
	private WebServiceTemplate webServiceTemplate;

	public GetBookResponse getItem(GetBookRequest itemRequest) {
		webServiceTemplate = new WebServiceTemplate(jaxb2Marshaller);

		String url = "http://localhost:9091/ws";
		return (GetBookResponse) webServiceTemplate.marshalSendAndReceive(url, itemRequest);
	}
	
	public GetBookResponse getItemInfo(GetBookRequest itemRequest){
        webServiceTemplate = new WebServiceTemplate(jaxb2Marshaller);
        return (GetBookResponse) webServiceTemplate.marshalSendAndReceive("http://localhost:9091/ws",itemRequest, new WebServiceMessageCallback() {
			
			@Override
			public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
				try {
					SoapHeader header = ((SoapMessage) message).getSoapHeader();
					QName name = new QName("token");
					header.addAttribute(name, "yRQYnWzskCZUxPwaQupWkiUzKELZ49eM7oWxAQK_ZXw");
				} catch (Exception e) {
					System.err.println("error : " + e);
				}
				
			}
		});
    }

}
