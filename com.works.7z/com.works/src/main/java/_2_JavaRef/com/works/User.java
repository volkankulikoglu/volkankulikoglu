package _2_JavaRef.com.works;

public class User implements Arayuz {

	public User() {

	}

	public User(int a) {

	}

	private int a;
	private String name;
	private boolean statu;

	public int sum(int a, int b) {
		return a + b;
	}

}
