package _2_JavaRef.com.works;

import java.util.Set;

import org.openjdk.jol.info.ClassLayout;
import org.reflections.Reflections;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Reflections reflections = new Reflections("_2_JavaRef.com.works");
		Set<Class<? extends Arayuz>> allClass = reflections.getSubTypesOf(Arayuz.class);
		System.out.println(allClass.size());

		for (Class<? extends Arayuz> item : allClass) {
			System.out.println(ClassLayout.parseClass(item).toPrintable());
		}
	}
}
