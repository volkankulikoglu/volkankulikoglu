package _2_JavaRef.com.works;

public class Settings implements Arayuz{

	
}
