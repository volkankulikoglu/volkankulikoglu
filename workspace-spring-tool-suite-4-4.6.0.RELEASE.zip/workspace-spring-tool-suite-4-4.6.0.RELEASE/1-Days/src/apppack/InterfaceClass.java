package apppack;

import iUsers.IUserSettings;

public class InterfaceClass implements IUserSettings {

	@Override
	public void userCall() {

		innerClass in = new innerClass();
		in.tst();
		
		
		int i = minus(40, 10);
		System.out.println("InterfaceClass run");
		
		System.out.println("end :" + end);
		
	}

	@Override
	public int sum(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
