package appPackTwo;

import apppack.Settings;

public class Util extends Settings {

	public Util() {
		super("Kurucu Util");
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
		// super.test();

		System.out.println("Hello Days");
	}

	public void callX() {

		System.out.println("callX Call");
		test();
		boolean statu = false;
		if (statu) {
			test();
		} else {
			super.test();

		}

		a = 100;
		// age = 100;
	}

}
