package iUsers;

public interface IUserSettings extends IUserDepo {
	
	int end = 100;
	
	public int sum (int a, int b);
	
	default public int minus (int a, int b) {
		return a - b;
	}
	
	class innerClass {
		
		public void tst() {
			System.out.println("InterfaceClass tst call");
			
		}
	}

}
