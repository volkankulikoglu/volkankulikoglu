package appPack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainApp {

	static List<User> ls = new ArrayList<>();

	public static void main(String[] args) {

		dataResult();

		long start = System.currentTimeMillis();

		ls.stream().filter(item -> item.getId() > 0).forEach(item -> {
			// System.out.println(item.getName());
		});

		long end = System.currentTimeMillis();

		long between = end - start;

		System.out.println("stream between: " + between);

		// parallel stream
		start = System.currentTimeMillis();

		ls.parallelStream().filter(item -> item.getId() > 0).forEach(item -> {
			// System.out.println(item.getName());
		});

		end = System.currentTimeMillis();

		between = end - start;

		System.out.println("pallel stream between: " + between);
		
		// String +
		String data = "days";
		System.out.println("1." + data);
		
		StringBuilder sb = new StringBuilder();
		sb.append("1. ");
		sb.append("days");
		System.out.println(sb.toString());

	}

	public static void dataResult() {

		for (int i = 0; i < 100000; i++) {
			User us = new User();
			us.setId(i);
			us.setName("Ali" + i);
			us.setRd(new Random());
			ls.add(us);
		}
	}

}
