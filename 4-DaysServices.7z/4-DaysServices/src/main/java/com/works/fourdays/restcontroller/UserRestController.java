package com.works.fourdays.restcontroller;

import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.util.LinkedMultiValueMap;
//import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.works.fourdays.model.Card;
import com.works.fourdays.model.JsonData;
import com.works.fourdays.model.Product;
import com.works.fourdays.restRepositories.ICardRepository;
import com.works.fourdays.restservices.ICardServices;

@RestController
@RequestMapping("/v1/user/")
public class UserRestController {

	@Autowired
	DriverManagerDataSource db;
	@Autowired
	ICardServices cardServices;
	@Autowired
	ICardRepository iCardRepository;

	@GetMapping("/insert")
	public Map<String, Object> insert() {
		Map<String, Object> hm = new HashMap<>();

		try {
			String query = "insert into user values (null, 'a', 'b', now())";
			PreparedStatement st = db.getConnection().prepareStatement(query);
			st.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		}

		hm.put("statu", true);

		return hm;
	}

	// jpa insert
	@PostMapping("/newCard")
	public ResponseEntity<Card> newCard(Card cr, HttpServletRequest req) {
		return cardServices.newCard(cr, req);
	}

	// jpa delete
	@DeleteMapping("/deleteCard")
	public Map<String, Object> deleteCard(@RequestParam long cid) {
		return cardServices.deleteCard(cid);
	}

	@GetMapping("/allCard")
	public Map<String, Object> allCard() {
		return cardServices.allCard();
	}

	@GetMapping("/findTelephone")
	public Map<String, Object> findTelephone(@RequestParam String telephone) {

		Map<String, Object> hm = new LinkedHashMap<String, Object>();
		hm.put("statu", true);
		hm.put("card", iCardRepository.findTelephone(telephone));

		return hm;
	}

	@GetMapping("/restUsing")
	public Map<String, Object> restUsing() {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();

		// RestTemplate --> Services using
		String url = "https://www.jsonbulut.com/json/product.php?ref={ref}&start={start}";
		// String url = "https://www.jsonbulut.com/json/product.php?";
		// send parameter

		Map<String, String> params = new HashMap<>();
		params.put("ref", "5380f5dbcc3b1021f93ab24c3a1aac24");
		params.put("start", "0");

		// MultiValueMap<String, String> headers = new LinkedMultiValueMap<String,
		// String>();
		// HttpEntity<?> header = new HttpEntity<>(params, headers);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> result = restTemplate.getForEntity(url, String.class, params);
		String data = result.getBody();
		System.out.println(data);

		Gson gson = new Gson();
		List<Product> pls = gson.fromJson(data, JsonData.class).getProducts();

		hm.put("statu", true);
		hm.put("allProduct", pls);

		return hm;
	}

	@GetMapping("/xmlRead")
	public Map<String, Object> xmlRead() {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		try {
			String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
			String data = Jsoup.connect(url).get().toString();
			Document doc = Jsoup.parse(data, "", Parser.xmlParser());
			
			Elements elements = doc.getElementsByTag("Currency");
			for (Element element : elements) {
				String Isim = element.getElementsByTag("Isim").text();
				String ForexBuying = element.getElementsByTag("ForexBuying").text();
				System.out.println("isim : " + Isim + " ForexBuying : " + ForexBuying);
			}
			//System.out.println(data);
		} catch (Exception e) {
			
		}
		
		return hm;
	}

}
