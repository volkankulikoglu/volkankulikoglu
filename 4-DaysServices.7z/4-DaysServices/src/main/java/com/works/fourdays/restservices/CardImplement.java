package com.works.fourdays.restservices;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.works.fourdays.model.Card;
import com.works.fourdays.restRepositories.ICardRepository;

@Service
public class CardImplement implements ICardServices {

	@Autowired
	ICardRepository cardRepository;

	@Override
	public ResponseEntity<Card> newCard(Card cr, HttpServletRequest req) {

		if (!cr.getCname().equals("")) {
			Card card = cardRepository.saveAndFlush(cr);

			return new ResponseEntity<Card>(card, HttpStatus.CREATED);
		}

		return null;
	}

	@Override
	public Map<String, Object> allCard() {

		Map<String, Object> hm = new LinkedHashMap<String, Object>();

		List<Card> ls = cardRepository.findAll();
		hm.put("statu", true);
		hm.put("size", ls.size());
		hm.put("cards", ls);

		return hm;
	}

	@Override
	public Map<String, Object> deleteCard(long cid) {
		Map<String, Object> hm = new LinkedHashMap<String, Object>();

		try {
			cardRepository.deleteById(cid);
			hm.put("statu", true);
			hm.put("deleteid", cid);
			hm.put("httpStatu", HttpStatus.OK);
		} catch (Exception e) {
			hm.put("statu", false);
			hm.put("message", "Deleted fail cid");
			hm.put("httpStatu", HttpStatus.BAD_REQUEST);
		}

		return hm;
	}

	public Card findTelephone(String telephone) {
		return cardRepository.findTelephone(telephone);
	}

}
