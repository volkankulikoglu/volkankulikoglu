package com.works.fourdays.restservices;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import com.works.fourdays.model.Card;

public interface ICardServices {

	public ResponseEntity<Card> newCard(Card cr, HttpServletRequest req);
	
	public Map<String, Object> allCard();
	
	public Map<String, Object> deleteCard(long cid);
}
