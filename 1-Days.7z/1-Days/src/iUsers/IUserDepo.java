package iUsers;

public interface IUserDepo {
	
	public void userCall();
}
