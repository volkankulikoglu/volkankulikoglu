package apppack;

import java.awt.List;
import java.util.ArrayList;

import abs.AbsUser;
import appPackTwo.User;
import appPackTwo.Util;
import iUsers.IUserDepo;
import iUsers.IUserSettings;

public class MainApp extends AbsUser {

	public static void main(String[] args) {
		Settings st = new Settings();
		// st.test();

		Util ut = new Util();
		User us = new User();

		call(st);
		call(ut);
		call(us);

		// List<String> ls = new ArrayList<>();
		Settings utx = new Util();
		// utx
		//

		IUserSettings usts = new InterfaceClass();
		// usts.userCall();
		callIner(usts);

		IUserDepo userDepo = new IUserDepo() {

			@Override
			public void userCall() {
				System.out.println("userCall call");

				
				// System.out.println();

			}
			
			int a = 10;
		};

	}

	public static void call(Settings st) {

		if (st instanceof Util) {
			Util ut = (Util) st;
			ut.callX();
		}

		st.test();
	}

	public static void callIner(IUserSettings ust) {

		ust.userCall();
	}

	@Override
	public int sum(int a, int b) {
		// TODO Auto-generated method stub
		return a + b;
	}

}
