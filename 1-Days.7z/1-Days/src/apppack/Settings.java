package apppack;

public class Settings {

	public Settings() {
		System.out.println("Default Settings");
	}

	public Settings(String data) {
		System.out.println("Default Settings" + data);
		Settings.fncPicture();
	}

	public void test() {
		System.out.println("test java");
	}

	public int a = 10;
	public String name = "Volkan";
	final public int age = 40;

	final void fncUser() {
		System.out.println("final fncuser");
	}

	static void fncPicture() {
		System.out.println("static fncPicture");
	}
}
