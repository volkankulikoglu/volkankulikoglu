package appPackTwo;

import apppack.Settings;

public class User extends Settings  {
	
	@Override
	public void test() {
		// TODO Auto-generated method stub
		//super.test();
		
		System.out.println("Hello User");
	}

}